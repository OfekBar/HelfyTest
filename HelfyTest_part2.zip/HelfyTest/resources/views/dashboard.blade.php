@extends('layout')
<h1>Server Messages:<h1>
    <table border="1%" align="center">
        <tr>
            <td class="tableHead"> Header</td>
        <td class="tableHead">Contant</td>
    <td class="tableHead">Time</td>
 </tr>
 <?php foreach ($data as $message){
    echo "<tr>
    <td class='tableBlock'> {$message['message_title']}</td>
<td class='tableBlock'>{$message['message_body']}</td>
<td class='tableBlock'>{$message['message_time']}</td>
</tr>";
    
 }
 ?>
</table>