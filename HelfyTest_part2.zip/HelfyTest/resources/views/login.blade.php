@extends('layout')

 <form action="{{ route('login.post') }}" method="POST">
                          @csrf
    
    <h1> System Login</h1>
    <div class="parameters">
        <label for="email_address" class="col-md-4 col-form-label text-md-right">Username\Email</label>
            <div class="col-md-6">
                <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                    @if ($errors->has('email'))
                     <span class="text-danger">{{ $errors->first('email') }}</span>
                    @endif
            </div>
    </div>
    <div class="parameters">
        <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                <div class="col-md-6">
                    <input type="password" id="password" class="form-control" name="password" required>
                        @if ($errors->has('password'))
                        <span class="text-danger">{{ $errors->first('password') }}</span>
                         @endif
                </div>
    </div>
    <div class="press">
        <button type="submit" class="press">Login</button>
    </div>
</form>
                    
