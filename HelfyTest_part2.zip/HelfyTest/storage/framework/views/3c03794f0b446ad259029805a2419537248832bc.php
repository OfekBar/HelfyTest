

 <form action="<?php echo e(route('login.post')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
    
    <h1> System Login</h1>
    <div class="parameters">
        <label for="email_address" class="col-md-4 col-form-label text-md-right">Username\Email</label>
            <div class="col-md-6">
                <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                    <?php if($errors->has('email')): ?>
                     <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
            </div>
    </div>
    <div class="parameters">
        <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                <div class="col-md-6">
                    <input type="password" id="password" class="form-control" name="password" required>
                        <?php if($errors->has('password')): ?>
                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                         <?php endif; ?>
                </div>
    </div>
    <div class="press">
        <button type="submit" class="press">Login</button>
    </div>
</form>
                    

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ofek/HelfyTest/resources/views/login.blade.php ENDPATH**/ ?>