
<h1> Error 401!</h1>
<h2> It seems like your username and password didn't match!</h2>
<h2> Please try to  <a class="nav-link" href="<?php echo e(route('login')); ?>">login</a> again.</h2>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ofek/HelfyTest/resources/views/failed.blade.php ENDPATH**/ ?>