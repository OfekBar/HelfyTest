<!DOCTYPE html>
<html>
<head>

    <style type="text/css">

  
        body{
            margin: 0;
            font-size: .9rem;
            font-weight: 400;
            line-height: 1.6;
            color: #212529;
            text-align: center;
            background-color: #e6ccff;
        }
        h1{
            font-size:200%;
            font-weight:700;
            color: #212529;
            font-family: 'Goudy Old Style';
        }
        h2{
            font-size:100%;
            font-weight:600;
            color: #212529;
            font-family: 'Goudy Old Style';
        }

        .press{
            background-color: #c180ff;
            color: black;
            padding: 50% 20%px;
            text-align: center;
            display: inline-flex;
            font-size: 100%;
            border:1px;
            size
            font-family: 'Goudy Old Style';

        }
        .parameters{
            font-size:100%;
            font-weight:700;
            color: #212529;
            font-family: 'Goudy Old Style';
        }
        .tableHead{
            font-size:120%;
            font-weight:900;
            text-align:center;
            color: #212529;
            font-family: 'Goudy Old Style';
            background-color:#df80ff;
        }
        .tableBlock{
            padding-right: 5%;
            padding-left:2%;
            padding-top:2%;
            padding-bottom:2%;
            text-align:left;
            background-color:#f3e6ff;
        }
        .nav-link{
            font-size: 150%;
            font-weight:900;
            font-family:'Goudy Old Style';

        }
</head>
<body>
  
<?php echo $__env->yieldContent('content'); ?>
     
</body>
</html><?php /**PATH /home/ofek/HelfyTest/resources/views/layout.blade.php ENDPATH**/ ?>