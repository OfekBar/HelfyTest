<?php
  
namespace App\Http\Controllers;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use App\Models\message;
use Hash;
use Illuminate\Support\Facades\DB;
class AuthController extends Controller
{
   
    public function index()
    {
        return view('login');
    }  
      
    
    public function postLogin(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
   
        $credentials = $request->only('email', 'password');
        $names = DB::table('users')->where('email', $credentials['email']);
        if (($names->value('password'))!= ($credentials['password'])) {
            return redirect("failed")->with('message', '401');
        }
        return  redirect("dashboard")->with('message', '200');
    }
      
    
    public function dashboard()
    {
            $mess=message::all();
            return view('dashboard',['data'=>$mess]);
    }
    public function failed(){
        return view('failed');
    }
    
}
?>